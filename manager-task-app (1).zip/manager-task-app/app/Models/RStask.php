<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class RStask extends Model
{
    use HasFactory;

    protected $fillable = [
        'title',
        'description',
        'status',
        'user_id'
    ];

    protected $casts = [
        'status' => 'string',
    ];

    protected $table = 'rstasks'; 

    public function user()
    {
        return $this->belongsTo(RSuser::class);
    }
}