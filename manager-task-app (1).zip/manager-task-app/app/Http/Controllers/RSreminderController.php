<?php 

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\Mail;
use App\Mail\TaskReminder;

class RSreminderController extends RScontroller
{
    public function setReminder(Request $request)
    {
        $request->validate([
            'email' => 'required|email'
        ]);

        try {
            // Store the email in database if needed
            // $reminder = Reminder::create(['email' => $request->email]);
            
            // Send confirmation email
            Mail::to($request->email)->send(new TaskReminder());
            
            return response()->json([
                'success' => true,
                'message' => 'Reminder set successfully'
            ]);
        } catch (\Exception $e) {
            return response()->json([
                'success' => false,
                'message' => 'Failed to set reminder: ' . $e->getMessage()
            ], 500);
        }
    }
}
