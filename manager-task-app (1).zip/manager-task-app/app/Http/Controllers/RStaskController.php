<?php

namespace App\Http\Controllers;

use App\Models\RStask;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use App\Models\RSuser;

class RStaskController extends RScontroller
{
    public function index()
    {
        $tasks = RStask::where('user_id', Auth::id())
                    ->orderBy('status')
                    ->orderBy('created_at', 'desc')
                    ->get();
        
        $pendingTasks = $tasks->where('status', 'pending');
        $inProgressTasks = $tasks->where('status', 'in_progress');
        $completedTasks = $tasks->where('status', 'completed');

        return view('tasks.index', compact('pendingTasks', 'inProgressTasks', 'completedTasks'));
    }

    // 👇 New create() method added here
    

    public function create()
{
    $users = RSuser::all(); // Get all users
    return view('tasks.create', compact('users'));
}

    public function store(Request $request)
    {
        $request->validate([
            'title' => 'required|string|max:255',
            'description' => 'nullable|string',
        ]);

        RStask::create([
            'title' => $request->title,
            'description' => $request->description,
            'status' => 'pending',
            'user_id' => Auth::id(),
        ]);

        return redirect()->route('tasks.index')->with('success', 'Task added successfully!');
    }

    public function update(Request $request, RStask $task)
    {
        $this->authorize('update', $task);

        $request->validate([
            'status' => 'required|in:pending,in_progress,completed',
        ]);

        $task->update([
            'status' => $request->status,
        ]);

        return redirect()->route('tasks.index')->with('success', 'Task status updated!');
    }

    public function destroy(RStask $task)
    {
        $this->authorize('delete', $task);

        $task->delete();

        return redirect()->route('tasks.index')->with('success', 'Task deleted successfully!');
    }
}