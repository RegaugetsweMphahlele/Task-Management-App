<?php

namespace App\Policies;

use App\Models\RStask;
use App\Models\RSuser;
use Illuminate\Auth\Access\HandlesAuthorization;

class TaskPolicy
{
    /**
     * Determine whether the user can view any models.
     */
     use HandlesAuthorization;

    public function view(RSuser $user, RStask $task)
    {
        return $user->id === $task->user_id;
    }

    public function update(RSuser $user, RStask $task)
    {
        return $user->id === $task->user_id;
    }

    public function delete(RSuser $user, RStask $task)
    {
        return $user->id === $task->user_id;
    }

    
}
