<!DOCTYPE html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>" class="h-full">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">

    <title><?php echo e(config('app.name', 'Laravel')); ?> - Authentication</title>

    <!-- Favicon -->
    <link rel="icon" type="image/png" href="/favicon.png">

    <!-- Fonts -->
    <link rel="preconnect" href="https://fonts.bunny.net">
    <link href="https://fonts.bunny.net/css?family=figtree:400,500,600&display=swap" rel="stylesheet" />

    <!-- Scripts -->
    <?php echo app('Illuminate\Foundation\Vite')(['resources/css/app.css', 'resources/js/app.js']); ?>

    <style>
        /* Custom scrollbar */
        ::-webkit-scrollbar {
            width: 6px;
            height: 6px;
        }
        ::-webkit-scrollbar-track {
            background: #f1f1f1;
            border-radius: 10px;
        }
        ::-webkit-scrollbar-thumb {
            background: #c1c1c1;
            border-radius: 10px;
        }
        ::-webkit-scrollbar-thumb:hover {
            background: #a8a8a8;
        }

        /* Smooth transitions */
        .transition-smooth {
            transition: all 0.2s ease-in-out;
        }

        /* Background pattern */
        .auth-bg {
            background-color: #f9fafb;
            background-image: 
                radial-gradient(at 80% 0%, hsla(189, 100%, 56%, 0.05) 0px, transparent 50%),
                radial-gradient(at 0% 50%, hsla(355, 100%, 93%, 0.1) 0px, transparent 50%);
        }
    </style>
</head>
<body class="font-sans text-gray-800 antialiased h-full auth-bg">
    <div class="min-h-screen flex flex-col sm:justify-center items-center p-6">
        <!-- Logo -->
        <div class="mb-8">
            <a href="/" class="inline-block transition-smooth hover:scale-105">
                <?php if (isset($component)) { $__componentOriginal8892e718f3d0d7a916180885c6f012e7 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal8892e718f3d0d7a916180885c6f012e7 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.application-logo','data' => ['class' => 'w-24 h-24 fill-current text-indigo-600']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('application-logo'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['class' => 'w-24 h-24 fill-current text-indigo-600']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal8892e718f3d0d7a916180885c6f012e7)): ?>
<?php $attributes = $__attributesOriginal8892e718f3d0d7a916180885c6f012e7; ?>
<?php unset($__attributesOriginal8892e718f3d0d7a916180885c6f012e7); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal8892e718f3d0d7a916180885c6f012e7)): ?>
<?php $component = $__componentOriginal8892e718f3d0d7a916180885c6f012e7; ?>
<?php unset($__componentOriginal8892e718f3d0d7a916180885c6f012e7); ?>
<?php endif; ?>
            </a>
        </div>

        <!-- Card Container -->
        <div class="w-full sm:max-w-md bg-white shadow-xl rounded-xl overflow-hidden transition-smooth hover:shadow-2xl">
            <!-- Card Header (for tabs if needed) -->
            <div class="px-6 py-4 border-b border-gray-100 bg-white">
                <?php if(isset($header)): ?>
                    <h2 class="text-2xl font-bold text-center text-gray-800">
                        <?php echo e($header); ?>

                    </h2>
                <?php endif; ?>
            </div>

            <!-- Flash Messages -->
            <?php if(session('status')): ?>
                <div class="px-6 py-3 bg-blue-50 text-blue-700 text-sm font-medium">
                    <?php echo e(session('status')); ?>

                </div>
            <?php endif; ?>

            <?php if($errors->any()): ?>
                <div class="px-6 py-3 bg-red-50 text-red-700 text-sm font-medium">
                    <ul>
                        <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <li><?php echo e($error); ?></li>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </ul>
                </div>
            <?php endif; ?>

            <!-- Card Content -->
            <div class="px-6 py-8">
                <?php echo e($slot); ?>

            </div>
        </div>

        <!-- Footer Links -->
        <div class="mt-8 text-center text-sm text-gray-500">
            <?php if(Route::has('login')): ?>
                <a href="<?php echo e(route('login')); ?>" class="hover:text-gray-700 underline transition-smooth">
                    Already registered?
                </a>
            <?php endif; ?>

            <?php if(Route::has('register')): ?>
                <span class="mx-2">•</span>
                <a href="<?php echo e(route('register')); ?>" class="hover:text-gray-700 underline transition-smooth">
                    Need an account?
                </a>
            <?php endif; ?>
        </div>
    </div>
</body>
</html><?php /**PATH C:\laravel-projects\manager-task-app\resources\views/layouts/guest.blade.php ENDPATH**/ ?>