<?php if (isset($component)) { $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54 = $attributes; } ?>
<?php $component = App\View\Components\AppLayout::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\AppLayout::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
     <?php $__env->slot('header', null, []); ?> 
        <div class="flex justify-between items-center">
            <h2 class="font-semibold text-xl text-gray-800 leading-tight">
                TaskFlow
            </h2>
            <div class="flex space-x-4">
                <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('create', App\Models\Task::class)): ?>
                <a href="<?php echo e(route('tasks.create')); ?>" class="inline-flex items-center px-4 py-2 bg-indigo-600 border border-transparent rounded-md font-semibold text-xs text-white uppercase tracking-widest hover:bg-indigo-700 focus:bg-indigo-700 active:bg-indigo-900 focus:outline-none focus:ring-2 focus:ring-indigo-500 focus:ring-offset-2 transition ease-in-out duration-150">
                    + New Task
                </a>
                <?php endif; ?>
            </div>
        </div>
     <?php $__env->endSlot(); ?>

    <div class="py-6">
        <div class="max-w-7xl mx-auto sm:px-6 lg:px-8">
            <!-- Stats Cards -->
            <div class="grid grid-cols-1 md:grid-cols-3 gap-6 mb-8">
                <div class="bg-white overflow-hidden shadow-sm sm:rounded-lg border border-gray-200">
                    <div class="p-6 bg-white">
                        <div class="flex items-center">
                            <div class="p-3 rounded-full bg-gray-100 text-gray-600 mr-4">
                                <svg xmlns="http://www.w3.org/2000/svg" class="h-6 w-6" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                                    <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M9 5H7a2 2 0 00-2 2v12a2 2 0 002 2h10a2 2 0 002-2V7a2 2 0 00-2-2h-2M9 5a2 2 0 002 2h2a2 2 0 002-2M9 5a2 2 0 012-2h2a2 2 0 012 2" />
                                </svg>
                            </div>
                            <div>
                                <p class="text-sm font-medium text-gray-500">Pending Tasks</p>
                                <p class="text-2xl font-semibold text-gray-900"><?php echo e($pendingTasks->count()); ?></p>
                            </div>
                        </div>
                    </div>
                </div>

                <div class="bg-white overflow-hidden shadow-sm sm:rounded-lg border border-gray-200">
                    <div class="p-6 bg-white">
                        <div class="flex items-center">
                            <div class="p-3 rounded-full bg-blue-100 text-blue-600 mr-4">
                                <svg xmlns="http://www.w3.org/2000/svg" class="h-6 w-6" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                                    <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M12 8v4l3 3m6-3a9 9 0 11-18 0 9 9 0 0118 0z" />
                                </svg>
                            </div>
                            <div>
                                <p class="text-sm font-medium text-gray-500">In Progress</p>
                                <p class="text-2xl font-semibold text-gray-900"><?php echo e($inProgressTasks->count()); ?></p>
                            </div>
                        </div>
                    </div>
                </div>

                <div class="bg-white overflow-hidden shadow-sm sm:rounded-lg border border-gray-200">
                    <div class="p-6 bg-white">
                        <div class="flex items-center">
                            <div class="p-3 rounded-full bg-green-100 text-green-600 mr-4">
                                <svg xmlns="http://www.w3.org/2000/svg" class="h-6 w-6" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                                    <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M5 13l4 4L19 7" />
                                </svg>
                            </div>
                            <div>
                                <p class="text-sm font-medium text-gray-500">Completed</p>
                                <p class="text-2xl font-semibold text-gray-900"><?php echo e($completedTasks->count()); ?></p>
                            </div>
                        </div>
                    </div>
                </div>
            </div>

            <!-- Task Status Columns -->
            <div class="grid grid-cols-1 md:grid-cols-3 gap-6">
                <!-- Pending Tasks -->
                <div class="bg-white overflow-hidden shadow-sm sm:rounded-lg border border-gray-200">
                    <div class="p-4 border-b border-gray-200 bg-gray-50">
                        <div class="flex justify-between items-center">
                            <h3 class="text-lg font-medium text-gray-900">Pending (<?php echo e($pendingTasks->count()); ?>)</h3>
                        </div>
                    </div>
                    <div class="p-4 space-y-4">
                        <?php $__empty_1 = true; $__currentLoopData = $pendingTasks; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $task): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                            <div class="bg-white p-4 rounded-lg border border-gray-200 hover:shadow-md transition-shadow">
                                <div class="flex justify-between items-start">
                                    <div class="w-full">
                                        <div class="flex justify-between items-start w-full">
                                            <h4 class="font-medium text-gray-900"><?php echo e($task->title); ?></h4>
                                            <div class="flex space-x-2">
                                                <form action="<?php echo e(route('tasks.update', $task)); ?>" method="POST">
                                                    <?php echo csrf_field(); ?>
                                                    <?php echo method_field('PUT'); ?>
                                                    <input type="hidden" name="status" value="in_progress">
                                                    <button type="submit" class="text-xs bg-blue-50 text-blue-600 px-2 py-1 rounded hover:bg-blue-100">
                                                        Start
                                                    </button>
                                                </form>
                                                <form action="<?php echo e(route('tasks.destroy', $task)); ?>" method="POST">
                                                    <?php echo csrf_field(); ?>
                                                    <?php echo method_field('DELETE'); ?>
                                                    <button type="submit" class="text-xs bg-gray-50 text-gray-600 px-2 py-1 rounded hover:bg-gray-100">
                                                        Delete
                                                    </button>
                                                </form>
                                            </div>
                                        </div>
                                        <?php if($task->description): ?>
                                            <p class="text-sm text-gray-600 mt-1"><?php echo e($task->description); ?></p>
                                        <?php endif; ?>
                                        <div class="mt-3 pt-3 border-t border-gray-100">
                                            <div class="flex justify-between items-center">
                                                <div class="flex flex-wrap gap-2">
                                                    <span class="text-xs px-2 py-1 rounded <?php echo e($task->priority === 'high' ? 'bg-red-50 text-red-600 border border-red-100' : ($task->priority === 'medium' ? 'bg-yellow-50 text-yellow-600 border border-yellow-100' : 'bg-green-50 text-green-600 border border-green-100')); ?>">
                                                        <?php echo e(ucfirst($task->priority)); ?> Priority
                                                    </span>
                                                    <?php if($task->category): ?>
                                                        <span class="text-xs px-2 py-1 rounded bg-gray-50 text-gray-600 border border-gray-100">
                                                            <?php echo e($task->category->name); ?>

                                                        </span>
                                                    <?php endif; ?>
                                                </div>
                                            </div>
                                            <div class="mt-2 flex justify-between items-center">
                                                <?php if($task->due_date): ?>
                                                    <span class="text-xs px-2 py-1 rounded bg-gray-50 text-gray-600 border border-gray-100">
                                                        Due: <?php echo e($task->due_date->format('M d, Y')); ?>

                                                    </span>
                                                <?php endif; ?>
                                                <?php if($task->assignee): ?>
                                                    <div class="text-xs text-gray-500 flex items-center">
                                                        <svg xmlns="http://www.w3.org/2000/svg" class="h-3 w-3 mr-1" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                                                            <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M16 7a4 4 0 11-8 0 4 4 0 018 0zM12 14a7 7 0 00-7 7h14a7 7 0 00-7-7z" />
                                                        </svg>
                                                        <?php echo e($task->assignee->name); ?>

                                                    </div>
                                                <?php endif; ?>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                            <div class="bg-gray-50 p-4 rounded-lg text-center border border-gray-200">
                                <p class="text-sm text-gray-500">No pending tasks</p>
                            </div>
                        <?php endif; ?>
                    </div>
                </div>

                <!-- In Progress Tasks -->
                <div class="bg-white overflow-hidden shadow-sm sm:rounded-lg border border-gray-200">
                    <div class="p-4 border-b border-gray-200 bg-gray-50">
                        <div class="flex justify-between items-center">
                            <h3 class="text-lg font-medium text-gray-900">In Progress (<?php echo e($inProgressTasks->count()); ?>)</h3>
                        </div>
                    </div>
                    <div class="p-4 space-y-4">
                        <?php $__empty_1 = true; $__currentLoopData = $inProgressTasks; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $task): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                            <div class="bg-white p-4 rounded-lg border border-gray-200 hover:shadow-md transition-shadow">
                                <div class="flex justify-between items-start">
                                    <div class="w-full">
                                        <div class="flex justify-between items-start w-full">
                                            <h4 class="font-medium text-gray-900"><?php echo e($task->title); ?></h4>
                                            <div class="flex space-x-2">
                                                <form action="<?php echo e(route('tasks.update', $task)); ?>" method="POST">
                                                    <?php echo csrf_field(); ?>
                                                    <?php echo method_field('PUT'); ?>
                                                    <input type="hidden" name="status" value="completed">
                                                    <button type="submit" class="text-xs bg-green-50 text-green-600 px-2 py-1 rounded hover:bg-green-100">
                                                        Complete
                                                    </button>
                                                </form>
                                                <form action="<?php echo e(route('tasks.destroy', $task)); ?>" method="POST">
                                                    <?php echo csrf_field(); ?>
                                                    <?php echo method_field('DELETE'); ?>
                                                    <button type="submit" class="text-xs bg-gray-50 text-gray-600 px-2 py-1 rounded hover:bg-gray-100">
                                                        Delete
                                                    </button>
                                                </form>
                                            </div>
                                        </div>
                                        <?php if($task->description): ?>
                                            <p class="text-sm text-gray-600 mt-1"><?php echo e($task->description); ?></p>
                                        <?php endif; ?>
                                        <div class="mt-3 pt-3 border-t border-gray-100">
                                            <div class="flex justify-between items-center">
                                                <div class="flex flex-wrap gap-2">
                                                    <span class="text-xs px-2 py-1 rounded <?php echo e($task->priority === 'high' ? 'bg-red-50 text-red-600 border border-red-100' : ($task->priority === 'medium' ? 'bg-yellow-50 text-yellow-600 border border-yellow-100' : 'bg-green-50 text-green-600 border border-green-100')); ?>">
                                                        <?php echo e(ucfirst($task->priority)); ?> Priority
                                                    </span>
                                                    <?php if($task->category): ?>
                                                        <span class="text-xs px-2 py-1 rounded bg-gray-50 text-gray-600 border border-gray-100">
                                                            <?php echo e($task->category->name); ?>

                                                        </span>
                                                    <?php endif; ?>
                                                </div>
                                            </div>
                                            <div class="mt-2 flex justify-between items-center">
                                                <?php if($task->due_date): ?>
                                                    <span class="text-xs px-2 py-1 rounded bg-gray-50 text-gray-600 border border-gray-100">
                                                        Due: <?php echo e($task->due_date->format('M d, Y')); ?>

                                                    </span>
                                                <?php endif; ?>
                                                <?php if($task->assignee): ?>
                                                    <div class="text-xs text-gray-500 flex items-center">
                                                        <svg xmlns="http://www.w3.org/2000/svg" class="h-3 w-3 mr-1" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                                                            <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M16 7a4 4 0 11-8 0 4 4 0 018 0zM12 14a7 7 0 00-7 7h14a7 7 0 00-7-7z" />
                                                        </svg>
                                                        <?php echo e($task->assignee->name); ?>

                                                    </div>
                                                <?php endif; ?>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                            <div class="bg-gray-50 p-4 rounded-lg text-center border border-gray-200">
                                <p class="text-sm text-gray-500">No tasks in progress</p>
                            </div>
                        <?php endif; ?>
                    </div>
                </div>

                <!-- Completed Tasks -->
                <div class="bg-white overflow-hidden shadow-sm sm:rounded-lg border border-gray-200">
                    <div class="p-4 border-b border-gray-200 bg-gray-50">
                        <div class="flex justify-between items-center">
                            <h3 class="text-lg font-medium text-gray-900">Completed (<?php echo e($completedTasks->count()); ?>)</h3>
                        </div>
                    </div>
                    <div class="p-4 space-y-4">
                        <?php $__empty_1 = true; $__currentLoopData = $completedTasks; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $task): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                            <div class="bg-white p-4 rounded-lg border border-gray-200 hover:shadow-md transition-shadow">
                                <div class="flex justify-between items-start">
                                    <div class="w-full">
                                        <div class="flex justify-between items-start w-full">
                                            <h4 class="font-medium text-gray-900 line-through"><?php echo e($task->title); ?></h4>
                                            <div class="flex space-x-2">
                                                <form action="<?php echo e(route('tasks.destroy', $task)); ?>" method="POST">
                                                    <?php echo csrf_field(); ?>
                                                    <?php echo method_field('DELETE'); ?>
                                                    <button type="submit" class="text-xs bg-gray-50 text-gray-600 px-2 py-1 rounded hover:bg-gray-100">
                                                        Delete
                                                    </button>
                                                </form>
                                            </div>
                                        </div>
                                        <?php if($task->description): ?>
                                            <p class="text-sm text-gray-600 mt-1 line-through"><?php echo e($task->description); ?></p>
                                        <?php endif; ?>
                                        <div class="mt-3 pt-3 border-t border-gray-100">
                                            <div class="flex justify-between items-center">
                                                <div class="flex flex-wrap gap-2">
                                                    <span class="text-xs px-2 py-1 rounded <?php echo e($task->priority === 'high' ? 'bg-red-50 text-red-600 border border-red-100' : ($task->priority === 'medium' ? 'bg-yellow-50 text-yellow-600 border border-yellow-100' : 'bg-green-50 text-green-600 border border-green-100')); ?>">
                                                        <?php echo e(ucfirst($task->priority)); ?> Priority
                                                    </span>
                                                    <?php if($task->category): ?>
                                                        <span class="text-xs px-2 py-1 rounded bg-gray-50 text-gray-600 border border-gray-100">
                                                            <?php echo e($task->category->name); ?>

                                                        </span>
                                                    <?php endif; ?>
                                                </div>
                                            </div>
                                            <div class="mt-2 flex justify-between items-center">
                                                <span class="text-xs px-2 py-1 rounded bg-gray-50 text-gray-600 border border-gray-100">
                                                    Completed: <?php echo e($task->updated_at->format('M d, Y')); ?>

                                                </span>
                                                <?php if($task->assignee): ?>
                                                    <div class="text-xs text-gray-500 flex items-center">
                                                        <svg xmlns="http://www.w3.org/2000/svg" class="h-3 w-3 mr-1" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                                                            <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M16 7a4 4 0 11-8 0 4 4 0 018 0zM12 14a7 7 0 00-7 7h14a7 7 0 00-7-7z" />
                                                        </svg>
                                                        <?php echo e($task->assignee->name); ?>

                                                    </div>
                                                <?php endif; ?>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                            <div class="bg-gray-50 p-4 rounded-lg text-center border border-gray-200">
                                <p class="text-sm text-gray-500">No completed tasks</p>
                            </div>
                        <?php endif; ?>
                    </div>
                </div>
            </div>
        </div>
    </div>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $attributes = $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $component = $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?><?php /**PATH C:\laravel-projects\manager-task-app\resources\views/tasks/index.blade.php ENDPATH**/ ?>