<?php if (isset($component)) { $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54 = $attributes; } ?>
<?php $component = App\View\Components\AppLayout::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\AppLayout::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
     <?php $__env->slot('header', null, []); ?> 
        <div class="flex items-center justify-between">
            
            <a href="<?php echo e(route('tasks.index')); ?>" 
               class="flex items-center space-x-2 text-indigo-600 hover:text-indigo-800 transition-colors duration-200">
                <svg xmlns="http://www.w3.org/2000/svg" class="h-5 w-5" viewBox="0 0 20 20" fill="currentColor">
                    <path fill-rule="evenodd" d="M9.707 16.707a1 1 0 01-1.414 0l-6-6a1 1 0 010-1.414l6-6a1 1 0 011.414 1.414L5.414 9H17a1 1 0 110 2H5.414l4.293 4.293a1 1 0 010 1.414z" clip-rule="evenodd" />
                </svg>
                <span class="font-medium">Back to Tasks</span>
            </a>
        </div>
     <?php $__env->endSlot(); ?>

    <style>
        /* Enhanced Form Styling */
        .form-container {
            background: linear-gradient(to bottom right, #f9fafb, #f3f4f6);
        }
        
        .form-card {
            background: white;
            border-radius: 12px;
            box-shadow: 0 10px 25px -5px rgba(0, 0, 0, 0.05);
            transition: all 0.3s ease;
            border: 1px solid rgba(0, 0, 0, 0.05);
        }
        
        .form-card:hover {
            box-shadow: 0 20px 25px -5px rgba(79, 70, 229, 0.1);
        }
        
        .form-input {
            transition: all 0.3s ease;
            border: 1px solid #e5e7eb;
        }
        
        .form-input:focus {
            border-color: #a5b4fc;
            box-shadow: 0 0 0 3px rgba(199, 210, 254, 0.5);
        }
        
        .form-label {
            color: #374151;
            font-weight: 500;
        }
        
        .required-field::after {
            content: '*';
            color: #ef4444;
            margin-left: 4px;
        }
        
        .submit-btn {
            background: linear-gradient(to right, #6366f1, #8b5cf6);
            transition: all 0.3s ease;
            box-shadow: 0 4px 6px -1px rgba(79, 70, 229, 0.3);
        }
        
        .submit-btn:hover {
            background: linear-gradient(to right, #4f46e5, #7c3aed);
            transform: translateY(-2px);
            box-shadow: 0 10px 15px -3px rgba(79, 70, 229, 0.4);
        }
        
        .submit-btn:active {
            transform: translateY(0);
        }
        
        .error-icon {
            color: #ef4444;
        }
        
        .error-message {
            color: #ef4444;
            font-size: 0.875rem;
        }
        
        .divider {
            border-color: rgba(0, 0, 0, 0.08);
        }
    </style>

    <div class="py-8 form-container">
        <div class="max-w-3xl mx-auto px-4 sm:px-6 lg:px-8">
            <div class="form-card overflow-hidden">
                <div class="p-6 sm:p-8">
                    <form action="<?php echo e(route('tasks.store')); ?>" method="POST" class="space-y-6">
                        <?php echo csrf_field(); ?>
                        
                        <!-- Title Field -->
                        <div>
                            <label for="title" class="form-label required-field">
                                Task Title
                            </label>
                            <div class="mt-1 relative rounded-md shadow-sm">
                                <input type="text" name="title" id="title" required
                                    class="form-input block w-full px-4 py-3 rounded-lg focus:ring-2 focus:ring-indigo-500 transition duration-150 ease-in-out"
                                    placeholder="Enter task title">
                                <?php $__errorArgs = ['title'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <div class="absolute inset-y-0 right-0 pr-3 flex items-center pointer-events-none">
                                        <svg class="h-5 w-5 error-icon" fill="currentColor" viewBox="0 0 20 20">
                                            <path fill-rule="evenodd" d="M18 10a8 8 0 11-16 0 8 8 0 0116 0zm-7 4a1 1 0 11-2 0 1 1 0 012 0zm-1-9a1 1 0 00-1 1v4a1 1 0 102 0V6a1 1 0 00-1-1z" clip-rule="evenodd" />
                                        </svg>
                                    </div>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>
                            <?php $__errorArgs = ['title'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <p class="error-message mt-2"><?php echo e($message); ?></p>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>

                        <!-- Description Field -->
                        <div>
                            <label for="description" class="form-label">
                                Description
                            </label>
                            <textarea id="description" name="description" rows="4"
                                class="form-input block w-full px-4 py-3 rounded-lg shadow-sm focus:ring-2 focus:ring-indigo-500 transition duration-150 ease-in-out"
                                placeholder="Enter task description"></textarea>
                        </div>

                        <!-- Due Date and Status -->
                        <div class="grid grid-cols-1 md:grid-cols-2 gap-6">
                            <!-- Due Date -->
                            <div>
                                <label for="due_date" class="form-label">
                                    Due Date
                                </label>
                                <div class="mt-1 relative rounded-md shadow-sm">
                                    <input type="date" name="due_date" id="due_date"
                                        class="form-input block w-full px-4 py-3 rounded-lg focus:ring-2 focus:ring-indigo-500 transition duration-150 ease-in-out">
                                </div>
                            </div>

                            <!-- Status -->
                            <div>
                                <label for="status" class="form-label required-field">
                                    Status
                                </label>
                                <div class="mt-1 relative rounded-md shadow-sm">
                                    <select id="status" name="status" required
                                        class="form-input block w-full px-4 py-3 rounded-lg focus:ring-2 focus:ring-indigo-500 transition duration-150 ease-in-out">
                                        <option value="pending">Pending</option>
                                        <option value="in_progress">In Progress</option>
                                        <option value="completed">Completed</option>
                                    </select>
                                    <?php $__errorArgs = ['status'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <div class="absolute inset-y-0 right-0 pr-3 flex items-center pointer-events-none">
                                            <svg class="h-5 w-5 error-icon" fill="currentColor" viewBox="0 0 20 20">
                                                <path fill-rule="evenodd" d="M18 10a8 8 0 11-16 0 8 8 0 0116 0zm-7 4a1 1 0 11-2 0 1 1 0 012 0zm-1-9a1 1 0 00-1 1v4a1 1 0 102 0V6a1 1 0 00-1-1z" clip-rule="evenodd" />
                                            </svg>
                                        </div>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </div>
                                <?php $__errorArgs = ['status'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <p class="error-message mt-2"><?php echo e($message); ?></p>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>
                        </div>

                        <!-- Priority and Category -->
                        <div class="grid grid-cols-1 md:grid-cols-2 gap-6">
                            <!-- Priority -->
                            <div>
                                <label for="priority" class="form-label">
                                    Priority
                                </label>
                                <select id="priority" name="priority"
                                    class="form-input block w-full px-4 py-3 rounded-lg focus:ring-2 focus:ring-indigo-500 transition duration-150 ease-in-out">
                                    <option value="low">Low</option>
                                    <option value="medium" selected>Medium</option>
                                    <option value="high">High</option>
                                </select>
                            </div>

                            <!-- Category -->
                            <div>
                                <label for="category" class="form-label">
                                    Category
                                </label>
                                <input type="text" name="category" id="category"
                                    class="form-input block w-full px-4 py-3 rounded-lg focus:ring-2 focus:ring-indigo-500 transition duration-150 ease-in-out"
                                    placeholder="e.g. Development, Design">
                            </div>
                        </div>

                        <!-- Assignee (if applicable) -->
                        <?php if($users->count() > 0): ?>
                            <div>
                                <label for="assigned_to" class="form-label">
                                    Assign To
                                </label>
                                <select id="assigned_to" name="assigned_to"
                                    class="form-input block w-full px-4 py-3 rounded-lg focus:ring-2 focus:ring-indigo-500 transition duration-150 ease-in-out">
                                    <option value="">Unassigned</option>
                                    <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <option value="<?php echo e($user->id); ?>"><?php echo e($user->name); ?></option>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </select>
                            </div>
                        <?php endif; ?>

                        <div class="flex justify-end pt-6 border-t divider">
                            <button type="submit" 
                                    class="submit-btn inline-flex items-center px-8 py-3 border border-transparent text-base font-medium rounded-lg shadow-sm text-white focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-indigo-500 transition duration-150 ease-in-out">
                                <svg xmlns="http://www.w3.org/2000/svg" class="-ml-1 mr-3 h-5 w-5" viewBox="0 0 20 20" fill="currentColor">
                                    <path fill-rule="evenodd" d="M10 3a1 1 0 011 1v5h5a1 1 0 110 2h-5v5a1 1 0 11-2 0v-5H4a1 1 0 110-2h5V4a1 1 0 011-1z" clip-rule="evenodd" />
                                </svg>
                                Create Task
                            </button>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $attributes = $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $component = $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?><?php /**PATH C:\laravel-projects\manager-task-app\resources\views/tasks/create.blade.php ENDPATH**/ ?>