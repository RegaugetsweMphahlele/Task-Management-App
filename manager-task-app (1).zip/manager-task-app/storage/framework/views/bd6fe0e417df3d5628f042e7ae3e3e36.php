<?php if (isset($component)) { $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54 = $attributes; } ?>
<?php $component = App\View\Components\AppLayout::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\AppLayout::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
     <?php $__env->slot('header', null, []); ?> 
        <div class="flex justify-between items-center">
            
            
        </div>
     <?php $__env->endSlot(); ?>

    <style>
        /* Modern Glassmorphism Style */
        .feature-card {
            backdrop-filter: blur(10px);
            background: rgba(255, 255, 255, 0.7);
            border-radius: 20px;
            box-shadow: 0 8px 32px rgba(0, 0, 0, 0.1);
            border: 1px solid rgba(255, 255, 255, 0.3);
            transition: all 0.3s cubic-bezier(0.4, 0, 0.2, 1);
            overflow: hidden;
            position: relative;
        }
        
        .feature-card:hover {
            transform: translateY(-8px);
            box-shadow: 0 12px 28px rgba(79, 70, 229, 0.3);
            background: rgba(255, 255, 255, 0.9);
        }
        
        .feature-content {
            padding: 1.5rem;
            position: relative;
            z-index: 2;
        }
        
        .feature-options {
            position: absolute;
            top: 0;
            left: 0;
            right: 0;
            bottom: 0;
            background: rgba(255, 255, 255, 0.95);
            border-radius: 20px;
            padding: 1.5rem;
            display: flex;
            flex-direction: column;
            justify-content: center;
            opacity: 0;
            pointer-events: none;
            transition: all 0.3s ease;
            z-index: 3;
        }
        
        .feature-card.active .feature-options {
            opacity: 1;
            pointer-events: all;
        }
        
        .feature-icon {
            width: 56px;
            height: 56px;
            display: flex;
            align-items: center;
            justify-content: center;
            border-radius: 16px;
            margin-bottom: 1.5rem;
            background: linear-gradient(135deg, rgba(99, 102, 241, 0.1) 0%, rgba(168, 85, 247, 0.1) 100%);
        }
        
        .option-btn {
            display: block;
            width: 100%;
            padding: 0.75rem 1rem;
            margin-bottom: 0.5rem;
            text-align: left;
            border-radius: 12px;
            background: rgba(79, 70, 229, 0.05);
            color: #4f46e5;
            font-weight: 500;
            transition: all 0.2s ease;
        }
        
        .option-btn:hover {
            background: rgba(79, 70, 229, 0.1);
            transform: translateX(5px);
        }
        
        .close-options {
            position: absolute;
            top: 1rem;
            right: 1rem;
            width: 32px;
            height: 32px;
            display: flex;
            align-items: center;
            justify-content: center;
            border-radius: 50%;
            background: rgba(0, 0, 0, 0.05);
            cursor: pointer;
        }
        
        .action-btn {
            display: flex;
            flex-direction: column;
            align-items: center;
            justify-content: center;
            padding: 1.75rem;
            border-radius: 20px;
            background: rgba(255, 255, 255, 0.7);
            box-shadow: 0 8px 32px rgba(0, 0, 0, 0.05);
            transition: all 0.3s cubic-bezier(0.4, 0, 0.2, 1);
            text-align: center;
            height: 100%;
            backdrop-filter: blur(10px);
            border: 1px solid rgba(255, 255, 255, 0.3);
        }
        
        .action-btn:hover {
            transform: translateY(-8px);
            box-shadow: 0 12px 28px rgba(79, 70, 229, 0.2);
            background: rgba(255, 255, 255, 0.9);
        }
        
        .action-icon {
            width: 56px;
            height: 56px;
            display: flex;
            align-items: center;
            justify-content: center;
            border-radius: 16px;
            margin-bottom: 1.5rem;
            background: linear-gradient(135deg, rgba(99, 102, 241, 0.1) 0%, rgba(168, 85, 247, 0.1) 100%);
        }
        
        .features-grid {
            display: grid;
            grid-template-columns: repeat(auto-fill, minmax(300px, 1fr));
            gap: 2rem;
            margin-bottom: 3rem;
        }
        
        .actions-grid {
            display: grid;
            grid-template-columns: repeat(auto-fill, minmax(220px, 1fr));
            gap: 1.5rem;
        }

        .select-style {
            width: 100%;
            padding: 0.75rem 1rem;
            margin-bottom: 0.5rem;
            border-radius: 12px;
            border: 1px solid rgba(79, 70, 229, 0.2);
            background: rgba(255, 255, 255, 0.9);
            color: #4f46e5;
            font-weight: 500;
        }

        .email-form {
            display: flex;
            flex-direction: column;
            gap: 0.5rem;
        }

        .email-input {
            width: 100%;
            padding: 0.75rem 1rem;
            border-radius: 12px;
            border: 1px solid rgba(79, 70, 229, 0.2);
            background: rgba(255, 255, 255, 0.9);
        }

        .submit-btn {
            padding: 0.75rem 1rem;
            border-radius: 12px;
            background: rgba(79, 70, 229, 0.8);
            color: white;
            font-weight: 500;
            border: none;
            cursor: pointer;
            transition: background 0.2s ease;
        }

        .submit-btn:hover {
            background: rgba(79, 70, 229, 1);
        }

        .success-message {
            color: #10b981;
            font-size: 0.875rem;
            text-align: center;
            margin-top: 0.5rem;
            display: none;
        }

        .select-btn {
            padding: 0.75rem 1rem;
            border-radius: 12px;
            background: rgba(79, 70, 229, 0.8);
            color: white;
            font-weight: 500;
            border: none;
            cursor: pointer;
            transition: background 0.2s ease;
            width: 100%;
            margin-bottom: 0.5rem;
        }

        .select-btn:hover {
            background: rgba(79, 70, 229, 1);
        }
    </style>

    <div class="py-8">
        <div class="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
            <!-- Feature Buttons Grid -->
            <div class="features-grid">
                <!-- Create Tasks -->
                <div class="feature-card" onclick="toggleOptions(this)">
                    <div class="feature-content">
                        <div class="feature-icon">
                            <svg xmlns="http://www.w3.org/2000/svg" class="h-8 w-8 text-indigo-600" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M12 6v6m0 0v6m0-6h6m-6 0H6" />
                            </svg>
                        </div>
                        <h3 class="text-xl font-semibold text-gray-800 mb-2">Create Tasks</h3>
                        <p class="text-sm text-gray-600">Add new tasks with details and assignees</p>
                    </div>
                    <div class="feature-options">
                        <div class="close-options" onclick="event.stopPropagation(); toggleOptions(this.closest('.feature-card'))">
                            <svg xmlns="http://www.w3.org/2000/svg" class="h-5 w-5" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M6 18L18 6M6 6l12 12" />
                            </svg>
                        </div>
                        <a href="<?php echo e(route('tasks.create')); ?>" class="option-btn">
                            Quick Create
                        </a>
                    </div>
                </div>
                
                <!-- Edit Tasks -->
                <div class="feature-card" onclick="toggleOptions(this)">
                    <div class="feature-content">
                        <div class="feature-icon">
                            <svg xmlns="http://www.w3.org/2000/svg" class="h-8 w-8 text-indigo-600" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M11 5H6a2 2 0 00-2 2v11a2 2 0 002 2h11a2 2 0 002-2v-5m-1.414-9.414a2 2 0 112.828 2.828L11.828 15H9v-2.828l8.586-8.586z" />
                            </svg>
                        </div>
                        <h3 class="text-xl font-semibold text-gray-800 mb-2">Edit Tasks</h3>
                        <p class="text-sm text-gray-600">Modify existing tasks and update progress</p>
                    </div>
                    <div class="feature-options">
                        <div class="close-options" onclick="event.stopPropagation(); toggleOptions(this.closest('.feature-card'))">
                            <svg xmlns="http://www.w3.org/2000/svg" class="h-5 w-5" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M6 18L18 6M6 6l12 12" />
                            </svg>
                        </div>
                        <a href="<?php echo e(route('tasks.index')); ?>" class="option-btn">
                            View All Tasks
                        </a>
                    </div>
                </div>
                
                <!-- User Assignment -->
                <div class="feature-card" onclick="toggleOptions(this)">
                    <div class="feature-content">
                        <div class="feature-icon">
                            <svg xmlns="http://www.w3.org/2000/svg" class="h-8 w-8 text-indigo-600" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M16 7a4 4 0 11-8 0 4 4 0 018 0zM12 14a7 7 0 00-7 7h14a7 7 0 00-7-7z" />
                            </svg>
                        </div>
                        <h3 class="text-xl font-semibold text-gray-800 mb-2">User Assignment</h3>
                        <p class="text-sm text-gray-600">Assign tasks to team members</p>
                    </div>
                    <div class="feature-options">
                        <div class="close-options" onclick="event.stopPropagation(); toggleOptions(this.closest('.feature-card'))">
                            <svg xmlns="http://www.w3.org/2000/svg" class="h-5 w-5" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M6 18L18 6M6 6l12 12" />
                            </svg>
                        </div>
                        <select id="userAssignment" class="select-style">
                            <option value="">Select User</option>
                            <option value="unassigned">Unassigned</option>
                            <option value="guest">Guest User</option>
                            <option value="user1">John Doe</option>
                            <option value="user2">Jane Smith</option>
                            <option value="user3">Mike Johnson</option>
                        </select>
                        <button class="select-btn" onclick="event.stopPropagation(); assignUser()">
                            Assign Selected User
                        </button>
                    </div>
                </div>
                
                <!-- Categories -->
                <div class="feature-card" onclick="toggleOptions(this)">
                    <div class="feature-content">
                        <div class="feature-icon">
                            <svg xmlns="http://www.w3.org/2000/svg" class="h-8 w-8 text-indigo-600" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M9 5H7a2 2 0 00-2 2v12a2 2 0 002 2h10a2 2 0 002-2V7a2 2 0 00-2-2h-2M9 5a2 2 0 002 2h2a2 2 0 002-2M9 5a2 2 0 012-2h2a2 2 0 012 2" />
                            </svg>
                        </div>
                        <h3 class="text-xl font-semibold text-gray-800 mb-2">Categories</h3>
                        <p class="text-sm text-gray-600">Organize tasks by categories</p>
                    </div>
                    <div class="feature-options">
                        <div class="close-options" onclick="event.stopPropagation(); toggleOptions(this.closest('.feature-card'))">
                            <svg xmlns="http://www.w3.org/2000/svg" class="h-5 w-5" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M6 18L18 6M6 6l12 12" />
                            </svg>
                        </div>
                        <select id="taskCategory" class="select-style">
                            <option value="">Select Category</option>
                            <option value="development">Development</option>
                            <option value="design">Design</option>
                            <option value="marketing">Marketing</option>
                            <option value="testing">Testing</option>
                            <option value="planning">Planning</option>
                            <option value="other">Other</option>
                        </select>
                        <button class="select-btn" onclick="event.stopPropagation(); setCategory()">
                            Set Category
                        </button>
                    </div>
                </div>
                
                <!-- Priorities -->
                <div class="feature-card" onclick="toggleOptions(this)">
                    <div class="feature-content">
                        <div class="feature-icon">
                            <svg xmlns="http://www.w3.org/2000/svg" class="h-8 w-8 text-indigo-600" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M5 12h14M5 12a2 2 0 01-2-2V6a2 2 0 012-2h14a2 2 0 012 2v4a2 2 0 01-2 2M5 12a2 2 0 00-2 2v4a2 2 0 002 2h14a2 2 0 002-2v-4a2 2 0 00-2-2m-2-4h.01M17 16h.01" />
                            </svg>
                        </div>
                        <h3 class="text-xl font-semibold text-gray-800 mb-2">Priorities</h3>
                        <p class="text-sm text-gray-600">Set task priority levels</p>
                    </div>
                    <div class="feature-options">
                        <div class="close-options" onclick="event.stopPropagation(); toggleOptions(this.closest('.feature-card'))">
                            <svg xmlns="http://www.w3.org/2000/svg" class="h-5 w-5" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M6 18L18 6M6 6l12 12" />
                            </svg>
                        </div>
                        <select id="taskPriority" class="select-style">
                            <option value="">Select Priority</option>
                            <option value="low">Low</option>
                            <option value="medium">Medium</option>
                            <option value="high">High</option>
                            <option value="urgent">Urgent</option>
                        </select>
                        <button class="select-btn" onclick="event.stopPropagation(); setPriority()">
                            Set Priority
                        </button>
                    </div>
                </div>
                
                <!-- Status Updates -->
                <div class="feature-card" onclick="toggleOptions(this)">
                    <div class="feature-content">
                        <div class="feature-icon">
                            <svg xmlns="http://www.w3.org/2000/svg" class="h-8 w-8 text-indigo-600" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M9 12l2 2 4-4m6 2a9 9 0 11-18 0 9 9 0 0118 0z" />
                            </svg>
                        </div>
                        <h3 class="text-xl font-semibold text-gray-800 mb-2">Status Updates</h3>
                        <p class="text-sm text-gray-600">Track task progress stages</p>
                    </div>
                    <div class="feature-options">
                        <div class="close-options" onclick="event.stopPropagation(); toggleOptions(this.closest('.feature-card'))">
                            <svg xmlns="http://www.w3.org/2000/svg" class="h-5 w-5" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M6 18L18 6M6 6l12 12" />
                            </svg>
                        </div>
                        <select id="taskStatus" class="select-style">
                            <option value="">Select Status</option>
                            <option value="pending">Pending</option>
                            <option value="in_progress">In Progress</option>
                            <option value="completed">Completed</option>
                        </select>
                        <button class="select-btn" onclick="event.stopPropagation(); updateStatus()">
                            Update Status
                        </button>
                    </div>
                </div>
                
                <!-- Email Reminders Section (updated version) -->
<div class="feature-card" onclick="toggleOptions(this)">
    <div class="feature-content">
        <div class="feature-icon">
            <svg xmlns="http://www.w3.org/2000/svg" class="h-8 w-8 text-indigo-600" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M3 8l7.89 5.26a2 2 0 002.22 0L21 8M5 19h14a2 2 0 002-2V7a2 2 0 00-2-2H5a2 2 0 00-2 2v10a2 2 0 002 2z" />
            </svg>
        </div>
        <h3 class="text-xl font-semibold text-gray-800 mb-2">Email Reminders</h3>
        <p class="text-sm text-gray-600">Get deadline notifications</p>
    </div>
    <div class="feature-options">
        <div class="close-options" onclick="event.stopPropagation(); toggleOptions(this.closest('.feature-card'))">
            <svg xmlns="http://www.w3.org/2000/svg" class="h-5 w-5" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M6 18L18 6M6 6l12 12" />
            </svg>
        </div>
        <div class="email-form">
            <input type="email" id="reminderEmail" class="email-input" placeholder="Enter your email address">
            <button class="submit-btn" onclick="event.stopPropagation(); submitReminder(event)">Submit</button>
            <div id="reminderSuccess" class="success-message">You will receive email reminders at this address!</div>
            <div id="reminderError" class="error-message" style="display: none; color: #ef4444; font-size: 0.875rem; text-align: center; margin-top: 0.5rem;"></div>
        </div>
    </div>
</div>

<style>
    /* Add to your existing styles */
    .email-form {
        position: relative;
    }
    .loading-spinner {
        display: none;
        position: absolute;
        right: 10px;
        top: 10px;
        width: 20px;
        height: 20px;
        border: 3px solid rgba(79, 70, 229, 0.3);
        border-radius: 50%;
        border-top-color: #4f46e5;
        animation: spin 1s ease-in-out infinite;
    }
    @keyframes spin {
        to { transform: rotate(360deg); }
    }
</style>

<script>
    // Updated Email Reminder function
    async function submitReminder(event) {
        event.preventDefault();
        event.stopPropagation();
        
        const emailInput = document.getElementById('reminderEmail');
        const email = emailInput.value.trim();
        const successMessage = document.getElementById('reminderSuccess');
        const errorMessage = document.getElementById('reminderError');
        const submitBtn = event.target;
        
        // Validate email format
        const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
        
        if (!email) {
            errorMessage.textContent = 'Please enter an email address';
            errorMessage.style.display = 'block';
            return;
        }
        
        if (!emailRegex.test(email)) {
            errorMessage.textContent = 'Please enter a valid email address';
            errorMessage.style.display = 'block';
            return;
        }
        
        // Show loading state
        submitBtn.disabled = true;
        submitBtn.innerHTML = 'Sending...';
        
        try {
            // In a real app, this would call your backend API
            const response = await sendReminderEmail(email);
            
            if (response.success) {
                successMessage.style.display = 'block';
                errorMessage.style.display = 'none';
                emailInput.value = '';
                
                setTimeout(() => {
                    successMessage.style.display = 'none';
                }, 3000);
            } else {
                throw new Error(response.message || 'Failed to set reminder');
            }
        } catch (error) {
            errorMessage.textContent = error.message;
            errorMessage.style.display = 'block';
        } finally {
            submitBtn.disabled = false;
            submitBtn.innerHTML = 'Submit';
        }
    }

    
    async function sendReminderEmail(email) {
        
        return new Promise(resolve => {
            setTimeout(() => {
                resolve({ success: true, message: 'Reminder set successfully' });
            }, 1000);
        });
    }
</script>
                
                <!-- User Roles -->
                <div class="feature-card" onclick="toggleOptions(this)">
                    <div class="feature-content">
                        <div class="feature-icon">
                            <svg xmlns="http://www.w3.org/2000/svg" class="h-8 w-8 text-indigo-600" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M12 4.354a4 4 0 110 5.292M15 21H3v-1a6 6 0 0112 0v1zm0 0h6v-1a6 6 0 00-9-5.197M13 7a4 4 0 11-8 0 4 4 0 018 0z" />
                            </svg>
                        </div>
                        <h3 class="text-xl font-semibold text-gray-800 mb-2">User Roles</h3>
                        <p class="text-sm text-gray-600">Admin, Team Member, Guest</p>
                    </div>
                    <div class="feature-options">
                        <div class="close-options" onclick="event.stopPropagation(); toggleOptions(this.closest('.feature-card'))">
                            <svg xmlns="http://www.w3.org/2000/svg" class="h-5 w-5" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M6 18L18 6M6 6l12 12" />
                            </svg>
                        </div>
                        <select id="userRole" class="select-style">
                            <option value="">Select Role</option>
                            <option value="admin">Admin</option>
                            <option value="team_member">Team Member</option>
                            <option value="guest">Guest</option>
                        </select>
                        <button class="select-btn" onclick="event.stopPropagation(); setUserRole()">
                            Assign Role
                        </button>
                    </div>
                </div>
            </div>

            <!-- Quick Actions -->
            <div class="mb-8">
                <h3 class="text-2xl font-semibold text-gray-800 mb-6">Quick Actions</h3>
                <div class="actions-grid">
                    <a href="<?php echo e(route('tasks.create')); ?>" class="action-btn">
                        <div class="action-icon bg-indigo-100 text-indigo-600">
                            <svg xmlns="http://www.w3.org/2000/svg" class="h-8 w-8" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M12 6v6m0 0v6m0-6h6m-6 0H6" />
                            </svg>
                        </div>
                        <span class="text-base font-medium">Add Task</span>
                    </a>
                    
                    <a href="<?php echo e(route('tasks.index', ['status' => 'todo'])); ?>" class="action-btn">
                        <div class="action-icon bg-blue-100 text-blue-600">
                            <svg xmlns="http://www.w3.org/2000/svg" class="h-8 w-8" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M9 5H7a2 2 0 00-2 2v12a2 2 0 002 2h10a2 2 0 002-2V7a2 2 0 00-2-2h-2M9 5a2 2 0 002 2h2a2 2 0 002-2M9 5a2 2 0 012-2h2a2 2 0 012 2" />
                            </svg>
                        </div>
                        <span class="text-base font-medium">To Do</span>
                    </a>
                    
                    <a href="<?php echo e(route('tasks.index', ['status' => 'in_progress'])); ?>" class="action-btn">
                        <div class="action-icon bg-amber-100 text-amber-600">
                            <svg xmlns="http://www.w3.org/2000/svg" class="h-8 w-8" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M12 8v4l3 3m6-3a9 9 0 11-18 0 9 9 0 0118 0z" />
                            </svg>
                        </div>
                        <span class="text-base font-medium">In Progress</span>
                    </a>
                    
                    <a href="<?php echo e(route('tasks.index', ['status' => 'done'])); ?>" class="action-btn">
                        <div class="action-icon bg-green-100 text-green-600">
                            <svg xmlns="http://www.w3.org/2000/svg" class="h-8 w-8" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M9 12l2 2 4-4m6 2a9 9 0 11-18 0 9 9 0 0118 0z" />
                            </svg>
                        </div>
                        <span class="text-base font-medium">Completed</span>
                    </a>
                </div>
            </div>
        </div>
    </div>

    <script>
        function toggleOptions(card) {
            event.stopPropagation();
            document.querySelectorAll('.feature-card').forEach(el => {
                if (el !== card) el.classList.remove('active');
            });
            card.classList.toggle('active');
        }
        
        // Close options when clicking outside
        document.addEventListener('click', function(event) {
            if (!event.target.closest('.feature-card')) {
                document.querySelectorAll('.feature-card').forEach(el => {
                    el.classList.remove('active');
                });
            }
        });

        // User Assignment function
        function assignUser() {
            const selectedUser = document.getElementById('userAssignment').value;
            if (selectedUser) {
                alert(`Task assigned to: ${document.getElementById('userAssignment').options[document.getElementById('userAssignment').selectedIndex].text}`);
                // In a real app, you would send this to your backend
                // fetch('/api/assign-user', { method: 'POST', body: JSON.stringify({ user: selectedUser }) })
            } else {
                alert('Please select a user first');
            }
        }

        // Category function
        function setCategory() {
            const selectedCategory = document.getElementById('taskCategory').value;
            if (selectedCategory) {
                alert(`Category set to: ${document.getElementById('taskCategory').options[document.getElementById('taskCategory').selectedIndex].text}`);
                // In a real app, you would send this to your backend
            } else {
                alert('Please select a category first');
            }
        }

        // Priority function
        function setPriority() {
            const selectedPriority = document.getElementById('taskPriority').value;
            if (selectedPriority) {
                alert(`Priority set to: ${document.getElementById('taskPriority').options[document.getElementById('taskPriority').selectedIndex].text}`);
                // In a real app, you would send this to your backend
            } else {
                alert('Please select a priority first');
            }
        }

        // Status function
        function updateStatus() {
            const selectedStatus = document.getElementById('taskStatus').value;
            if (selectedStatus) {
                alert(`Status updated to: ${document.getElementById('taskStatus').options[document.getElementById('taskStatus').selectedIndex].text}`);
                // In a real app, you would send this to your backend
            } else {
                alert('Please select a status first');
            }
        }

        

        // User Role function
        function setUserRole() {
            const selectedRole = document.getElementById('userRole').value;
            if (selectedRole) {
                alert(`User role set to: ${document.getElementById('userRole').options[document.getElementById('userRole').selectedIndex].text}`);
                // In a real app, you would send this to your backend
            } else {
                alert('Please select a role first');
            }
        }
    </script>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $attributes = $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $component = $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?><?php /**PATH C:\laravel-projects\manager-task-app\resources\views/dashboard.blade.php ENDPATH**/ ?>