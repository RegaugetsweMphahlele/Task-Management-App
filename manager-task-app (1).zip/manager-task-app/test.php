<?php

$dir = 'bootstrap/cache/test.txt';

if (file_put_contents($dir, 'writable!')) {
    echo 'Success: Folder is writable.';
} else {
    echo 'Error: Folder is NOT writable.';
}
