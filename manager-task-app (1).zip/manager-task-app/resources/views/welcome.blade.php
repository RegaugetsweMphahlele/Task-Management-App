<!DOCTYPE html>
<html lang="{{ str_replace('_', '-', app()->getLocale()) }}">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="csrf-token" content="{{ csrf_token() }}">

    <title>{{ config('app.name', 'TaskMaster') }}</title>

    <!-- Fonts -->
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;600;700&display=swap" rel="stylesheet">

    <!-- Styles -->
    <style>
        :root {
            --primary: #4f46e5;
            --primary-light: #6366f1;
            --dark: #1f2937;
            --light: #f9fafb;
        }
        body {
            font-family: 'Inter', sans-serif;
            margin: 0;
            padding: 0;
            background-color: var(--light);
            color: var(--dark);
        }
        .hero {
            background: linear-gradient(135deg, var(--primary) 0%, var(--primary-light) 100%);
            color: white;
            padding: 5rem 1rem;
            text-align: center;
        }
        .container {
            max-width: 1200px;
            margin: 0 auto;
            padding: 0 1rem;
        }
        .cta-button {
            display: inline-block;
            background-color: white;
            color: var(--primary);
            padding: 0.75rem 1.5rem;
            border-radius: 0.375rem;
            font-weight: 600;
            text-decoration: none;
            margin: 0.5rem;
            transition: all 0.2s;
        }
        .cta-button:hover {
            transform: translateY(-2px);
            box-shadow: 0 4px 6px rgba(0, 0, 0, 0.1);
        }
        .features {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(300px, 1fr));
            gap: 2rem;
            padding: 4rem 1rem;
        }
        .feature-card {
            background: white;
            border-radius: 0.5rem;
            padding: 2rem;
            box-shadow: 0 1px 3px rgba(0, 0, 0, 0.1);
            transition: all 0.2s;
        }
        .feature-card:hover {
            transform: translateY(-5px);
            box-shadow: 0 10px 15px rgba(0, 0, 0, 0.1);
        }
        .feature-icon {
            font-size: 2.5rem;
            color: var(--primary);
            margin-bottom: 1rem;
        }
        footer {
            background-color: var(--dark);
            color: white;
            text-align: center;
            padding: 2rem 1rem;
            margin-top: 2rem;
        }
    </style>
</head>
<body>
    <div class="hero">
        <div class="container">
            <h1 style="font-size: 3rem; font-weight: 700; margin-bottom: 1rem;">Manage Your Tasks Effortlessly</h1>
            <p style="font-size: 1.25rem; max-width: 700px; margin: 0 auto 2rem;">
                TaskMaster helps you organize, prioritize, and complete your work. Never miss a deadline again.
            </p>
            <div>
                
                @if (Route::has('login'))
                    @auth
                        <a href="{{ url('/home') }}" class="cta-button">Go to Dashboard</a>
                    @else
                        <a href="{{ route('login') }}" class="cta-button">Log in</a>
                        @if (Route::has('register'))
                            <a href="{{ route('register') }}" class="cta-button" style="background-color: transparent; color: white; border: 2px solid white;">Register</a>
                        @endif
                    @endauth
                @endif
            </div>
        </div>
    </div>

    <div class="container">
        <div class="features">
            <div class="feature-card">
                <div class="feature-icon">📋</div>
                <h3>Task Management</h3>
                <p>Create, edit, and organize your tasks with ease. Set priorities and due dates to stay on track.</p>
            </div>
            <div class="feature-card">
                <div class="feature-icon">🚀</div>
                <h3>Productivity Boost</h3>
                <p>Visualize your workflow with status columns (To Do, In Progress, Done) to maximize efficiency.</p>
            </div>
            <div class="feature-card">
                <div class="feature-icon">🔒</div>
                <h3>Secure & Private</h3>
                <p>Your data is protected with industry-standard security measures and encryption.</p>
            </div>
        </div>
    </div>

    <footer>
        <div class="container">
            <p>© {{ date('Y') }} TaskMaster. All rights reserved.</p>
            <p>Laravel {{ Illuminate\Foundation\Application::VERSION }} (PHP {{ PHP_VERSION }})</p>
        </div>
    </footer>
</body>
</html>