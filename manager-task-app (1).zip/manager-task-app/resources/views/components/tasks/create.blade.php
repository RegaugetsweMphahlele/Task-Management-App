@extends('layouts.app')

@section('header')
    <h2 class="font-semibold text-xl text-gray-800 leading-tight">
        Create New Task
    </h2>
@endsection

@section('content')
<div class="py-6">
    <div class="max-w-3xl mx-auto sm:px-6 lg:px-8">
        <div class="bg-white shadow-sm rounded-lg overflow-hidden">
            <div class="p-6 bg-white border-b border-gray-200">
                <form action="{{ route('tasks.store') }}" method="POST">
                    @csrf
                    <div class="space-y-6">
                        <!-- Title Field -->
                        <div>
                            <label for="title" class="block text-sm font-medium text-gray-700 mb-1">Task Title</label>
                            <div class="mt-1 relative rounded-md shadow-sm">
                                <input type="text" name="title" id="title" required
                                    class="block w-full rounded-md border-gray-300 pl-3 pr-10 py-2 focus:border-blue-500 focus:ring-blue-500 transition duration-150 ease-in-out"
                                    placeholder="Enter task title">
                            </div>
                        </div>
                        
                        <!-- Category Field -->
                        <div>
                            <label for="category" class="block text-sm font-medium text-gray-700 mb-1">Category</label>
                            <div class="mt-1 relative rounded-md shadow-sm">
                                <input type="text" name="category" id="category"
                                    class="block w-full rounded-md border-gray-300 pl-3 pr-10 py-2 focus:border-blue-500 focus:ring-blue-500 transition duration-150 ease-in-out"
                                    placeholder="e.g., Design, Development, Marketing">
                            </div>
                        </div>
                        
                        <!-- Due Date Field -->
                        <div>
                            <label for="due_date" class="block text-sm font-medium text-gray-700 mb-1">Due Date</label>
                            <div class="mt-1 relative rounded-md shadow-sm">
                                <input type="date" name="due_date" id="due_date"
                                    class="block w-full rounded-md border-gray-300 pl-3 pr-10 py-2 focus:border-blue-500 focus:ring-blue-500 transition duration-150 ease-in-out">
                            </div>
                        </div>
                        
                        <!-- Action Buttons -->
                        <div class="flex justify-end space-x-3 pt-4">
                            <a href="{{ route('dashboard') }}" 
                                class="inline-flex items-center px-4 py-2 border border-gray-300 rounded-md shadow-sm text-sm font-medium text-gray-700 bg-white hover:bg-gray-50 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-blue-500 transition duration-150 ease-in-out">
                                Cancel
                            </a>
                            <button type="submit" 
                                class="inline-flex items-center px-4 py-2 border border-transparent rounded-md shadow-sm text-sm font-medium text-white bg-blue-600 hover:bg-blue-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-blue-500 transition duration-150 ease-in-out">
                                <svg class="-ml-1 mr-2 h-5 w-5" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 20 20" fill="currentColor">
                                    <path fill-rule="evenodd" d="M16.707 5.293a1 1 0 010 1.414l-8 8a1 1 0 01-1.414 0l-4-4a1 1 0 011.414-1.414L8 12.586l7.293-7.293a1 1 0 011.414 0z" clip-rule="evenodd" />
                                </svg>
                                Save Task
                            </button>
                        </div>
                    </div>
                </form>
            </div>
        </div>
    </div>
</div>

<style>
    /* Custom styling for date input */
    input[type="date"]::-webkit-calendar-picker-indicator {
        background: transparent;
        bottom: 0;
        color: transparent;
        cursor: pointer;
        height: auto;
        left: 0;
        position: absolute;
        right: 0;
        top: 0;
        width: auto;
    }
    
    /* Enhanced focus states */
    input:focus, button:focus {
        outline: 2px solid transparent;
        outline-offset: 2px;
    }
    
    /* Smooth transitions */
    .transition {
        transition-property: background-color, border-color, color, fill, stroke, opacity, box-shadow, transform;
        transition-timing-function: cubic-bezier(0.4, 0, 0.2, 1);
        transition-duration: 150ms;
    }
</style>
@endsection