<!DOCTYPE html>
<html lang="{{ str_replace('_', '-', app()->getLocale()) }}" class="h-full">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="csrf-token" content="{{ csrf_token() }}">

    <title>{{ config('app.name', 'Laravel') }} - Authentication</title>

    <!-- Favicon -->
    <link rel="icon" type="image/png" href="/favicon.png">

    <!-- Fonts -->
    <link rel="preconnect" href="https://fonts.bunny.net">
    <link href="https://fonts.bunny.net/css?family=figtree:400,500,600&display=swap" rel="stylesheet" />

    <!-- Scripts -->
    @vite(['resources/css/app.css', 'resources/js/app.js'])

    <style>
        /* Custom scrollbar */
        ::-webkit-scrollbar {
            width: 6px;
            height: 6px;
        }
        ::-webkit-scrollbar-track {
            background: #f1f1f1;
            border-radius: 10px;
        }
        ::-webkit-scrollbar-thumb {
            background: #c1c1c1;
            border-radius: 10px;
        }
        ::-webkit-scrollbar-thumb:hover {
            background: #a8a8a8;
        }

        /* Smooth transitions */
        .transition-smooth {
            transition: all 0.2s ease-in-out;
        }

        /* Background pattern */
        .auth-bg {
            background-color: #f9fafb;
            background-image: 
                radial-gradient(at 80% 0%, hsla(189, 100%, 56%, 0.05) 0px, transparent 50%),
                radial-gradient(at 0% 50%, hsla(355, 100%, 93%, 0.1) 0px, transparent 50%);
        }
    </style>
</head>
<body class="font-sans text-gray-800 antialiased h-full auth-bg">
    <div class="min-h-screen flex flex-col sm:justify-center items-center p-6">
        <!-- Logo -->
        <div class="mb-8">
            <a href="/" class="inline-block transition-smooth hover:scale-105">
                <x-application-logo class="w-24 h-24 fill-current text-indigo-600" />
            </a>
        </div>

        <!-- Card Container -->
        <div class="w-full sm:max-w-md bg-white shadow-xl rounded-xl overflow-hidden transition-smooth hover:shadow-2xl">
            <!-- Card Header (for tabs if needed) -->
            <div class="px-6 py-4 border-b border-gray-100 bg-white">
                @isset($header)
                    <h2 class="text-2xl font-bold text-center text-gray-800">
                        {{ $header }}
                    </h2>
                @endisset
            </div>

            <!-- Flash Messages -->
            @if(session('status'))
                <div class="px-6 py-3 bg-blue-50 text-blue-700 text-sm font-medium">
                    {{ session('status') }}
                </div>
            @endif

            @if($errors->any())
                <div class="px-6 py-3 bg-red-50 text-red-700 text-sm font-medium">
                    <ul>
                        @foreach ($errors->all() as $error)
                            <li>{{ $error }}</li>
                        @endforeach
                    </ul>
                </div>
            @endif

            <!-- Card Content -->
            <div class="px-6 py-8">
                {{ $slot }}
            </div>
        </div>

        <!-- Footer Links -->
        <div class="mt-8 text-center text-sm text-gray-500">
            @if(Route::has('login'))
                <a href="{{ route('login') }}" class="hover:text-gray-700 underline transition-smooth">
                    Already registered?
                </a>
            @endif

            @if(Route::has('register'))
                <span class="mx-2">•</span>
                <a href="{{ route('register') }}" class="hover:text-gray-700 underline transition-smooth">
                    Need an account?
                </a>
            @endif
        </div>
    </div>
</body>
</html>