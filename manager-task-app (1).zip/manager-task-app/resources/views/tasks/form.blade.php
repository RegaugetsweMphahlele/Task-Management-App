@props(['task' => null])

<div class="space-y-6">
    <!-- Title Field -->
    <div>
        <label for="title" class="block text-sm font-medium text-gray-700 mb-1">Title</label>
        <input type="text" id="title" name="title" value="{{ old('title', $task->title ?? '') }}" required
               class="mt-1 block w-full rounded-lg border-gray-300 shadow-sm focus:border-blue-500 focus:ring-blue-500 px-4 py-2 border transition duration-150 ease-in-out">
        @error('title')
            <p class="mt-2 text-sm text-red-600">{{ $message }}</p>
        @enderror
    </div>

    <!-- Description Field -->
    <div>
        <label for="description" class="block text-sm font-medium text-gray-700 mb-1">Description</label>
        <textarea id="description" name="description" rows="4"
                  class="mt-1 block w-full rounded-lg border-gray-300 shadow-sm focus:border-blue-500 focus:ring-blue-500 px-4 py-2 border transition duration-150 ease-in-out">{{ old('description', $task->description ?? '') }}</textarea>
    </div>

    <!-- Due Date Field -->
    <div>
        <label for="due_date" class="block text-sm font-medium text-gray-700 mb-1">Due Date</label>
        <input type="date" id="due_date" name="due_date" value="{{ old('due_date', optional($task->due_date ?? null)->format('Y-m-d') }}"
               class="mt-1 block w-full rounded-lg border-gray-300 shadow-sm focus:border-blue-500 focus:ring-blue-500 px-4 py-2 border transition duration-150 ease-in-out">
    </div>

    <!-- Priority Field -->
    <div>
        <label class="block text-sm font-medium text-gray-700 mb-2">Priority</label>
        <div class="mt-1 flex space-x-6">
            <label class="inline-flex items-center">
                <input type="radio" name="priority" value="low" 
                       {{ old('priority', $task->priority ?? 'medium') === 'low' ? 'checked' : '' }} 
                       class="h-4 w-4 text-blue-600 focus:ring-blue-500 border-gray-300">
                <span class="ml-2 text-gray-700">Low</span>
            </label>
            <label class="inline-flex items-center">
                <input type="radio" name="priority" value="medium" 
                       {{ old('priority', $task->priority ?? 'medium') === 'medium' ? 'checked' : '' }} 
                       class="h-4 w-4 text-blue-600 focus:ring-blue-500 border-gray-300">
                <span class="ml-2 text-gray-700">Medium</span>
            </label>
            <label class="inline-flex items-center">
                <input type="radio" name="priority" value="high" 
                       {{ old('priority', $task->priority ?? 'medium') === 'high' ? 'checked' : '' }} 
                       class="h-4 w-4 text-blue-600 focus:ring-blue-500 border-gray-300">
                <span class="ml-2 text-gray-700">High</span>
            </label>
        </div>
        @error('priority')
            <p class="mt-2 text-sm text-red-600">{{ $message }}</p>
        @enderror
    </div>

    @if(isset($task))
    <!-- Status Field -->
    <div>
        <label class="block text-sm font-medium text-gray-700 mb-2">Status</label>
        <div class="mt-1 flex space-x-6">
            <label class="inline-flex items-center">
                <input type="radio" name="status" value="todo" 
                       {{ old('status', $task->status ?? 'todo') === 'todo' ? 'checked' : '' }} 
                       class="h-4 w-4 text-blue-600 focus:ring-blue-500 border-gray-300">
                <span class="ml-2 text-gray-700">To Do</span>
            </label>
            <label class="inline-flex items-center">
                <input type="radio" name="status" value="in_progress" 
                       {{ old('status', $task->status ?? 'todo') === 'in_progress' ? 'checked' : '' }} 
                       class="h-4 w-4 text-blue-600 focus:ring-blue-500 border-gray-300">
                <span class="ml-2 text-gray-700">In Progress</span>
            </label>
            <label class="inline-flex items-center">
                <input type="radio" name="status" value="done" 
                       {{ old('status', $task->status ?? 'todo') === 'done' ? 'checked' : '' }} 
                       class="h-4 w-4 text-blue-600 focus:ring-blue-500 border-gray-300">
                <span class="ml-2 text-gray-700">Done</span>
            </label>
        </div>
        @error('status')
            <p class="mt-2 text-sm text-red-600">{{ $message }}</p>
        @enderror
    </div>
    @endif
</div>
