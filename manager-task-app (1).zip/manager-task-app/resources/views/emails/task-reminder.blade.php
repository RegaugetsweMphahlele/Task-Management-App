
<!DOCTYPE html>
<html>
<head>
    <title>Task Reminder Subscription</title>
</head>
<body>
    <h1>Thank You for Subscribing to Task Reminders</h1>
    <p>You'll now receive email notifications about your upcoming task deadlines.</p>
    <p>If you didn't request this, please ignore this email.</p>
</body>
</html>